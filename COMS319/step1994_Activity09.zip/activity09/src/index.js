import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './step1994_Activity09_Modules_Components_Props_App.jsx';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
